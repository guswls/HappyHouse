package com.ssafy.happyhouse.dao;

import java.util.List;

import com.ssafy.happyhouse.dto.Reply;

public interface ReplyDAO {
	List<Reply> selectReplyByBoardNo(int boardNo);
	public int insertReply(Reply reply);
	public int updateReply(Reply reply);
	public int deleteReply(int replyNo);
}
