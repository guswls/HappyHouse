package com.ssafy.happyhouse.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.happyhouse.dao.ReplyDAO;
import com.ssafy.happyhouse.dto.Reply;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ReplyServiceImpl implements ReplyService {

	@Autowired
	ReplyDAO dao;
	
	@Override
	public List<Reply> selectReplyByBoardNo(int boardNo) {
		// TODO Auto-generated method stub
		return dao.selectReplyByBoardNo(boardNo);
	}

	@Override
	public boolean insertReply(Reply reply) {
		// TODO Auto-generated method stub
		return dao.insertReply(reply) == 1;
	}

	@Override
	public boolean updateReply(Reply reply) {
		// TODO Auto-generated method stub
		return dao.updateReply(reply) == 1;
	}

	@Override
	public boolean deleteReply(int replyNo) {
		// TODO Auto-generated method stub
		return dao.deleteReply(replyNo) == 1;
	}

}
