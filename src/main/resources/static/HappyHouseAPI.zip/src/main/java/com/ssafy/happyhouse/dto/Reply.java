package com.ssafy.happyhouse.dto;

import java.util.Date;

public class Reply {
	private int replyNo;
	private int boardNo;
	private String replyContent;
	private Date replyDatetime;
	private String replyUserid;
	public Reply() {
		super();
	}
	public Reply(int replyNo, int boardNo, String replyContent, Date replyDatetime, String replyUserid) {
		super();
		this.replyNo = replyNo;
		this.boardNo = boardNo;
		this.replyContent = replyContent;
		this.replyDatetime = replyDatetime;
		this.replyUserid = replyUserid;
	}
	public int getReplyNo() {
		return replyNo;
	}
	public void setReplyNo(int replyNo) {
		this.replyNo = replyNo;
	}
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public String getReplyContent() {
		return replyContent;
	}
	public void setReplyContent(String replyContent) {
		this.replyContent = replyContent;
	}
	public Date getReplyDatetime() {
		return replyDatetime;
	}
	public void setReplyDatetime(Date replyDatetime) {
		this.replyDatetime = replyDatetime;
	}
	public String getReplyUserid() {
		return replyUserid;
	}
	public void setReplyUserid(String replyUserid) {
		this.replyUserid = replyUserid;
	}
	@Override
	public String toString() {
		return "Reply [replyNo=" + replyNo + ", boardNo=" + boardNo + ", replyContent=" + replyContent
				+ ", replyDatetime=" + replyDatetime + ", replyUserid=" + replyUserid + "]";
	}
}