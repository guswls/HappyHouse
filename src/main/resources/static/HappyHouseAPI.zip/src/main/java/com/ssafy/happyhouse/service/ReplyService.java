package com.ssafy.happyhouse.service;

import java.util.List;

import com.ssafy.happyhouse.dto.Reply;

public interface ReplyService {
	List<Reply> selectReplyByBoardNo(int boardNo);
	public boolean insertReply(Reply reply);
	public boolean updateReply(Reply reply);
	public boolean deleteReply(int replyNo);
}
